% In this demo, four CNN-based semantic segmentation models for BUS segmentation 
% are tested:
%   1) Fully Convolutional Network (FCN) with AlexNet network.
%   2) U-Net network.
%   3) SegNet using VGG16 and VGG19 networks.
%   4) DeepLabV3+ using ResNet18, ResNet50, MobileNet-V2, and Xception networks.
% All the CNN models were fine-tuned using transfer learning on a dataset with 
% 3061 BUS images acquired from seven ultrasound devices, excepting the U-Net 
% model that was trained from scratch.
%
% Any use of our CNN models, please cite:
%   Wilfrido Gomez-Flores and Wagner Coelho de Albuquerque Pereira, 
%   "A Comparative Study of Pre-trained Convolutional Neural Networks for 
%   Semantic Segmentation of Breast Tumors in Ultrasound", 
%   Computers in Biology and Medicine, in press, 2020.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico) - LUS/PEB/COPPE/UFRJ (Brazil)
%   September 2020
%   Copyright (c) 2020, Wilfrido Gomez-Flores (wgomez@cinvestav.mx)
% ------------------------------------------------------------------------

clearvars; close all; clc;

% Download CNN models
if ~exist('CNNs', 'dir')
    CNN_url = 'https://www.tamps.cinvestav.mx/~wgomez/downloads/CNNs.zip';
    outputFolder = fullfile(pwd,'temp'); 
    CNN_zip = fullfile(outputFolder,'CNNs.zip');
    mkdir(outputFolder);
    fprintf('Downloading 749 MB CNN models for BUS segmentation...\n');
    websave(CNN_zip, CNN_url);
    fprintf('Unzipping CNN models for BUS segmentation...\n');
    unzip(CNN_zip, pwd);
    rmdir(outputFolder,'s');
end

pathCNN = fullfile(pwd,'CNNs');
testImages = cell(1,10);
for i = 1:10
    testImages{i} = sprintf('test%02d.png',i);
end

% Select a CNN model
nets = {'alexnet','unet','vgg16','vgg19','resnet18','resnet50','mobilenet','xception'};
choice = menu('Select a CNN model:',nets);
% Load CNN for semantic segmentation
load(fullfile(pathCNN,sprintf("cnn_%s.mat",nets{choice})));

% Read breast ultrasound test image obtained from
% https://www.ultrasoundcases.info/cases/breast-and-axilla/ 
img = menu('Select a BUS image:',testImages);
I0 = imread(fullfile(pwd,'images',testImages{img}));

% Resize image to 128x128x3
I1 = imresize(I0,[128 128],'bicubic');
I  = cat(3,I1,I1,I1);

% Segment with CNN
[S,~,P2] = semanticseg(I,net,'ExecutionEnvironment','gpu');
P = P2(:,:,2);

% Rescale to original size
S = imresize(S,size(I0),'nearest');
P = imresize(P,size(I0),'bicubic');

% Show results
figure('color',[1 1 1]);
subplot(1,3,1);
imshow(I0);
title('Breast ultrasound');
subplot(1,3,2); 
imshow(labeloverlay(I0,S,'Colormap',[0 1 0.5;1 0.1 0],'Transparency',0.5));
title(sprintf("Segmented with %s",nets{choice}));
subplot(1,3,3); 
imshow(mat2gray(P));
title('Probability map');