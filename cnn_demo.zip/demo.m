clearvars; close all; clc;

% Download CNN models
if ~exist('CNNs', 'dir')
    CNN_url = 'https://www.dropbox.com/s/laws3xbci45n95f/CNNs.zip?dl=1';
    outputFolder = fullfile(pwd,'temp'); 
    CNN_zip = fullfile(outputFolder,'CNNs.zip');
    mkdir(outputFolder);
    fprintf('Downloading 749 MB CNN models for BUS segmentation...\n');
    websave(CNN_zip, CNN_url);
    fprintf('Unzipping CNN models for BUS segmentation...\n');
    unzip(CNN_zip, pwd);
    rmdir(outputFolder,'s');
end

pathCNN = fullfile(pwd,'CNNs');
testImages = cell(1,10);
for i = 1:10
    testImages{i} = sprintf('test%02d.png',i);
end

% Select a CNN model
nets = {'alexnet','unet','vgg16','vgg19','resnet18','resnet50','mobilenet','xception'};
choice = menu('Select a CNN model:',nets);
% Load CNN for semantic segmentation
load(fullfile(pathCNN,sprintf("cnn_%s.mat",nets{choice})));

% Read breast ultrasound test image obtained from
% https://www.ultrasoundcases.info/cases/breast-and-axilla/ 
img = menu('Select a BUS image:',testImages);
I0 = imread(fullfile(pwd,'images',testImages{img}));

% Resize image to 128x128x3
I1 = imresize(I0,[128 128],'bicubic');
I  = cat(3,I1,I1,I1);

% Segment with CNN
[S,~,P2] = semanticseg(I,net,'ExecutionEnvironment','gpu');
P = P2(:,:,2);

% Rescale to original size
S = imresize(S,size(I0),'nearest');
P = imresize(P,size(I0),'bicubic');

% Show results
figure('color',[1 1 1]);
subplot(1,3,1);
imshow(I0);
title('Breast ultrasound');
subplot(1,3,2); 
imshow(labeloverlay(I0,S,'Colormap',[0 1 0.5;1 0.1 0],'Transparency',0.5));
title(sprintf("Segmented with %s",nets{choice}));
subplot(1,3,3); 
imshow(mat2gray(P));
title('Probability map');